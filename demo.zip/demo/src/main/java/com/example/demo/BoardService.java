package com.example.demo;

import java.util.List;

public interface BoardService {
    void insert(BoardDTO boardDTO);

    List<BoardDTO> getList();
}
