package com.example.demo;

import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class BoardDAO {
    final
    SqlSession session;

    public void insert(BoardDTO boardDTO) {
        session.insert("board.insert", boardDTO);
    }

    public List<BoardDTO> getList() {

        return session.selectList("board.list");
    }
}
